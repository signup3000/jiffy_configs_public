name "test"
description "test"
default_attributes(
   :test => {
        :version => "1.4.8",
        :user => "root",
        :group => "root"
        }
)
